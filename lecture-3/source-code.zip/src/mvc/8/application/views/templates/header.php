<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="width=device-width">
    <title><?php echo htmlspecialchars($title) ?></title>
  </head>
  <body>
    <h1><?php echo htmlspecialchars($title) ?></h1>
