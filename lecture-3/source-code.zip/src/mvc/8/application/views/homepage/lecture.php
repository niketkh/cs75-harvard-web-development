<ul>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/<?php echo $n ?>/slides<?php echo $n ?>.pdf">Slides</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/<?php echo $n ?>/lecture<?php echo $n ?>.mp4">Video</a></li>
</ul>
