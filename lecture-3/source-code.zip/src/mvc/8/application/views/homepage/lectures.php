<ul>
  <li><a href="lecture/0">Lecture 0</a></li>
  <li><a href="lecture/1">Lecture 1</a></li>
</ul>
