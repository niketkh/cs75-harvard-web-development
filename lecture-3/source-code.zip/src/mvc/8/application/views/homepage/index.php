<ul>
  <li><a href="lectures">Lectures</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/syllabus.pdf">Syllabus</a></li>
</ul>
