
<!DOCTYPE html>

<html>
  <head>
    <title>C$75 Finance</title>
  </head>
  <body>
    <form action="quote.php" method="get">
      <input name="symbol" type="text">
      <input type="submit">
    </form>
  </body>
</html>
