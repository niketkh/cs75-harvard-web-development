<?php /*

header.php

David J. Malan
malan@harvard.edu

A header for pages.

*/ ?>

<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="width=device-width">
    <title>CSCI S-75</title>
  </head>
  <body>
    <h1>CSCI S-75</h1>
