<?php /*

footer.php

David J. Malan
malan@harvard.edu

A footer for pages.

*/ ?>

  </body>
</html>
