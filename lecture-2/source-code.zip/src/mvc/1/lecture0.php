<?php /*

lecture0.php

David J. Malan
malan@harvard.edu

Represents a lecture.

*/ ?>

<?php require('header.php'); ?>

<ul>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/slides0.pdf">Slides</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/lecture0.mp4">Video</a></li>
</ul>

<?php require('footer.php'); ?>
