<?php

require_once('../includes/helpers.php');

?>

<?php render('header', array('title' => 'Lecture 0')); ?>

<ul>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/slides0.pdf">Slides</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/lecture0.mp4">Video</a></li>
</ul>

<?php render('footer'); ?>
