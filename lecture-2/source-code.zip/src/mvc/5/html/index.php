<?php

require_once('../includes/helpers.php');

?>


<?php render('header', array('title' => 'CSCI S-75')); ?>

<ul>
  <li><a href="lectures.php">Lectures</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/syllabus.pdf">Syllabus</a></li>
</ul>

<?php render('footer'); ?>
