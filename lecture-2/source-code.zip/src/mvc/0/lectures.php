<!--

lectures.php

David J. Malan
malan@harvard.edu

Links to lectures.

-->

<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="width=device-width">
    <title>Lectures</title>
  </head>
  <body>
    <h1>Lectures</h1>
    <ul>
      <li><a href="lecture0.php">Lecture 0</a></li>
      <li><a href="lecture1.php">Lecture 1</a></li>
    </ul>
  </body>
</html>
