<!--

lecture1.php

David J. Malan
malan@harvard.edu

Represents a lecture.

-->

<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="width=device-width">
    <title>Lecture 1</title>
  </head>
  <body>
    <h1>Lecture 1</h1>
    <ul>
      <li><a href="http://cdn.cs75.net/2012/summer/lectures/1/slides1.pdf">Slides</a></li>
      <li><a href="http://cdn.cs75.net/2012/summer/lectures/1/lecture1.mp4">Video</a></li>
    </ul>
  </body>
</html>
