<!--

index.php

David J. Malan
malan@harvard.edu

A homepage for the course.

-->

<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="width=device-width">
    <title>CSCI S-75</title>
  </head>
  <body>
    <h1>CSCI S-75</h1>
    <ul>
      <li><a href="lectures.php">Lectures</a></li>
      <li><a href="http://cdn.cs75.net/2012/summer/lectures/0/syllabus.pdf">Syllabus</a></li>
    </ul>
  </body>
</html>
