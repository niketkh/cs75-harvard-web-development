<?php

require_once('helpers.php');

?>

<?php render('header', array('title' => 'Lectures')); ?>

<ul>
  <li><a href="lecture0.php">Lecture 0</a></li>
  <li><a href="lecture1.php">Lecture 1</a></li>
</ul>

<?php render('footer'); ?>
