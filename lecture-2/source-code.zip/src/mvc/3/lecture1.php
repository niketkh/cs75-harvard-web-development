<?php

require_once('helpers.php');

?>

<?php render('header', array('title' => 'Lecture 1')); ?>

<ul>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/1/slides1.pdf">Slides</a></li>
  <li><a href="http://cdn.cs75.net/2012/summer/lectures/1/lecture1.mp4">Video</a></li>
</ul>

<?php render('footer'); ?>
