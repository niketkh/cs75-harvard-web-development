<?php

require_once('includes/helpers.php');

?>


<?php render('header', array('title' => 'CS164')); ?>

<ul>
  <li><a href="lectures.php">Lectures</a></li>
  <li><a href="http://cdn.cs164.net/2012/spring/lectures/0/syllabus.pdf">Syllabus</a></li>
</ul>

<?php render('footer'); ?>
