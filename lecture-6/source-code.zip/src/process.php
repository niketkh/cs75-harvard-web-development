<!-- quick and dirty dump of HTTP request -->

<pre>
  <? print_r($_REQUEST); ?>
</pre>

