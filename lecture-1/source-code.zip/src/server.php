<!DOCTYPE html>

<html>
  <head>
    <title>Google</title>
  </head>
  <body>
    <h1>You wanted to search for: <b><? print($_GET['q']) ?></b></h1>
  </body>
</html>
